import { useState } from 'react'

import './App.css'

// import Header from './components/header/Header.jsx'
import Transition from './components/petSimulation/Transition.jsx'
const App=()=> {


  return (
    <>
      {/* <Header/> */}
      <Transition/>
    </>
  )
}

export default App
