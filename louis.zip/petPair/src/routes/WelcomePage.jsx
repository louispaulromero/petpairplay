import Welcome from '../components/welcomePage/Welcome.jsx'

const WelcomePage = ()=>{
    return (
        <div>
            <Welcome/>
        </div>
    )
}

export default WelcomePage