import SimulationInstruction from '../components/petSimulation/SimulationInstruction.jsx'
const SimulationInstructionPage = () => {
    return (
        <div>
            <SimulationInstruction/>
            
        </div>
    )
}

export default SimulationInstructionPage;